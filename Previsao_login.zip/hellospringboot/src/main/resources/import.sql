insert into previsao (dia,minima,maxima,humidade,descricao) values ('QUARTA',15.3,20,35.1,'QUENTE');
insert into previsao (dia,minima,maxima,humidade,descricao) values ('QUINTA',14,18,40,'FRIO');
insert into previsao (dia,minima,maxima,humidade,descricao) values ('SEXTA',13,19,35.1,'NUBLADO');

insert into usuario (id, login, senha) values (1, 'admin', 'admin');